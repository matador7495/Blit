﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace $rootnamespace$
{
    public partial class $safeitemname$ : DevComponents.DotNetBar.Office2007Form
    {
        Connection_Query query = new Connection_Query();
        public $safeitemname$()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Bilit;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();

        private void frmSetting_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                cmd.Parameters.Clear();//pak kardane parameterha
                cmd.Connection = con;//etesal cmd b database
                cmd.CommandText = "Insert into tblsetting (NameAgency,TelA,AddressA) values (@a,@b,@c)";//ersal query roye database
                                                                                                     //etesal value ha b textbox
                cmd.Parameters.AddWithValue("@a", txtName.Text);
                cmd.Parameters.AddWithValue("@b", txtTel.Text);
                cmd.Parameters.AddWithValue("@c", txtAddress.Text);
                con.Open();//baaz kardane connection
                cmd.ExecuteNonQuery();//ejra dastor query
                con.Close();//bastan connection
                MessageBox.Show("عملیات با موفقیت انجام شد", "Bilit", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("خطایی رخ داده است، مجددا تلاش کنید", "Bilit", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                cmd.Parameters.Clear();
                cmd.Connection = con;
                cmd.CommandText = "Delete from tblsetting where ID=" + txtCode.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("عملیات با موفقیت انجام شد", "Bilit", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("خطایی رخ داده است، مجددا تلاش کنید", "Bilit", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            SqlDataReader dr;//khandane etelaat
            cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "Select * from tblsetting where id=@s";//address dehi query
            cmd.Parameters.AddWithValue("@s", txtCode.Text);
            con.Open();
            dr = cmd.ExecuteReader();//chon faghat meghdar khandanei hast
            if (dr.Read())
            {
                txtCode.Text = dr["ID"].ToString();
                txtName.Text = dr["NameAgency"].ToString();
                txtTel.Text = dr["TelA"].ToString();
                txtAddress.Text = dr["AddressA"].ToString();
            }
            else
            {
                txtCode.Text = "";
                MessageBox.Show("اطلاعاتی برای این کد پیدا نشد", "Bilit", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            try
            {
                cmd.Parameters.Clear();
                cmd.Connection = con;
                cmd.CommandText = "Update tblsetting set NameAgency='" + txtName.Text + "',TelA='" + txtTel.Text + "',AddressA='" + txtAddress.Text + "'where ID=" + txtCode.Text;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("عملیات با موفقیت انجام شد", "Bilit", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception)
            {
                MessageBox.Show("خطایی رخ داده است، مجددا تلاش کنید", "Bilit", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
